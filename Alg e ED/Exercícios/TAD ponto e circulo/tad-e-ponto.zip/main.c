// Programa cliente que utiliza os TADS CIRCULO e PONTO

#include "circulo.h"

int main(){
    float p1, p2, r, cp1, cp2;
    scanf(" %f %f %f %f %f", &p1, &p2, &cp1, &cp2, &r); //leitura dos dados

    /* utilização das funções: */
    PONTO *ponto = ponto_criar(p1, p2);
    ponto_print(ponto);


    PONTO *pontoC = ponto_criar(cp1, cp2);
    CIRCULO *circulo = circulo_criar(pontoC, r);

    PONTO *getPonto = circulo_get_ponto(circulo);
    float getx = ponto_get_x(getPonto);
    float gety = ponto_get_y(getPonto);
    float getRaio = circulo_get_raio(circulo);

    printf("Circulo: Centro (%.1f, %.1f), Raio = %.1f", getx, gety, getRaio);
}